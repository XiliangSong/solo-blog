title: 搭建属于自己的ngrok服务器，实现内网穿透，外网访问内网，可本地开发微信不需要上传服务器
date: '2019-08-04 16:37:15'
updated: '2019-08-04 16:37:15'
tags: [ngrok]
permalink: /articles/2019/08/04/1564907835669.html
---
转自[Sunny博客](https://www.sunnyos.com/article-show-48.html)

# 搭建属于自己的ngrok服务器，实现内网穿透，外网访问内网，可本地开发微信不需要上传服务器


**以下为本篇文章全部内容：**

视频教程：[http://video.tudou.com/v/XMTc4ODY3MTg4MA==.html](http://video.tudou.com/v/XMTc4ODY3MTg4MA==.html "搭建属于自己的ngrok服务器，实现内网穿透，外网访问内网，可本地开发微信不需要上传服务器")

        ngrok 是一个使用go语言编写的反向代理软件，通过在公共的端点和本地运行的 Web 服务器之间建立一个安全的通道。ngrok 可捕获和分析所有通道上的流量，便于后期分析和重放。在官方网站上面可以注册一个账号自己使用，不需要自己搭建也行，但是缺点就是速度慢，还有经常会连不上，所以我们可以通过自己搭建来解决这些问题。对于想本地开发或者想做内网穿透的话ngrok可以帮你这个忙，我们都知道在微信开发的时候，微信服务器只认80端口，这样导致我们哪怕修改一行代码都得把代码上传到服务器上面，就在传文件的时候就已经浪费了特别的时间了，而如果我们把ngrok用上的话就可以节省很多时间，因为外网完全可以访问到内网的web服务器上，哪怕是你自己的电脑。我之前也做过《[如何通过SocketLog进行web和微信开发调试](http://www.sunnyos.com/article-show-35.html "如何通过SocketLog进行web和微信开发调试")》的教程，如果把ngrok和SocketLog搭配起来用的话，我们调试起来就更方便了，除了做微信之外，我们在做支付功能的时候，处理异步回调也很麻烦，也得把文件上传到服务器上面去，可我们同样的使用ngrok和SocketLog结合起来用，我们可以不上传代码，也还可以通过浏览器console来查看处理的过程，快速的帮助我们排查错误。

    准备工作：

        1、一台拥有公网ip的服务器或者vps  

        2、把需要做的主域名解析到服务器上面

    软件下载地址：

    go的下载地址：http://www.golangtc.com/download

    git的下载地址：http://git-scm.com/downloads 绝对下载地址：https://www.kernel.org/pub/software/scm/git/git-2.6.0.tar.gz

    ngrok克隆地址：https://github.com/inconshreveable/ngrok.git

    准备映射的域名：ngrok.sunnyos.com

      

 安装git  

1、安装git，我安装的是2.6版本，防止会出现另一个错误，安装git所需要的依赖包

1. yum -y install zlib-devel openssl-devel perl hg cpio expat-devel gettext-devel curl curl-devel perl-ExtUtils-MakeMaker hg wget gcc gcc-c++

2、下载git

1. wget https://www.kernel.org/pub/software/scm/git/git-2.6.0.tar.gz

3、解压git

1. tar zxvf git-2.6.0.tar.gz

4、编译git

1. cd git-2.6.0
2. ./configure --prefix=/usr/local/git
3. make
4. make install

5、创建git的软连接

1. ln -s /usr/local/git/bin/* /usr/bin/

 安装go环境  

准备go环境，我的系统是32位的centos所以我下载386的包

1、下载go的软件包

1. wget http://www.golangtc.com/static/go/1.4.2/go1.4.2.linux-386.tar.gz

2、解压出来可以随便指定位置

1. tar -zxvf go1.4.2.linux-386.tar.gz
2. mv go /usr/local/

3、go的命令需要做软连接到/usr/bin

1. ln -s /usr/local/go/bin/* /usr/bin/

编译ngrok

1. cd /usr/local/
2. git clone https://github.com/inconshreveable/ngrok.git
3. export GOPATH=/usr/local/ngrok/
4. export NGROK_DOMAIN="ngrok.sunnyos.com"
5. cd ngrok

为域名生成证书

1. openssl genrsa -out rootCA.key 2048
2. openssl req -x509 -new -nodes -key rootCA.key -subj "/CN=$NGROK_DOMAIN" -days 5000 -out rootCA.pem
3. openssl genrsa -out server.key 2048
4. openssl req -new -key server.key -subj "/CN=$NGROK_DOMAIN" -out server.csr
5. openssl x509 -req -in server.csr -CA rootCA.pem -CAkey rootCA.key -CAcreateserial -out server.crt -days 5000

在软件源代码目录下面会生成一些证书文件，我们需要把这些文件拷贝到指定位置

1. cp rootCA.pem assets/client/tls/ngrokroot.crt
2. cp server.crt assets/server/tls/snakeoil.crt
3. cp server.key assets/server/tls/snakeoil.key

如果是在天朝的服务器需要改，香港或者国外的服务器不需要

1. vim /usr/local/ngrok/src/ngrok/log/logger.go
2. log "github.com/keepeye/log4go"

指定编译环境变量，如何确认GOOS和GOARCH，可以通过go env来查看

编译服务端

1. cd /usr/local/go/src
2. GOOS=linux GOARCH=386 ./make.bash
3. cd /usr/local/ngrok/
4. GOOS=linux GOARCH=386 make release-server

编译客户端，我的是mac os 64位操作系统，所以我的是下面的命令

1. cd /usr/local/go/src
2. GOOS=darwin GOARCH=amd64 ./make.bash
3. cd /usr/local/ngrok/
4. GOOS=darwin GOARCH=amd64 make release-client

Windows的客户端编译

1. cd /usr/local/go/src
2. GOOS=windows GOARCH=amd64 ./make.bash
3. cd /usr/local/ngrok/
4. GOOS=windows GOARCH=amd64 make release-client

客户端配置文件

1. server_addr: "ngrok.sunnyos.com:4443"
2. trust_host_root_certs: false

服务端启动

1. /usr/local/ngrok/bin/ngrokd -domain="$NGROK_DOMAIN" -httpAddr=":80"

客户端使用

1. ./ngrok -config=./ngrok.cfg -subdomain=blog 80
2. setsid ./ngrok -config=./ngrok.cfg -subdomain=test 80 #在linux下如果想后台运行

启动成功如下效果

![搭建属于自己的ngrok服务器，实现内网穿透，外网访问内网，可本地开发微信不需要上传服务器](https://www.sunnyos.com/upfiles/images/201510/0614440669181017.png)

---------------------------问题总汇，以下非重点，出现问题再看--------------------------

出现这个错误说明我们需要安装hg

package code.google.com/p/log4go: exec: "hg": executable file not found in $PATH

解决办法

1. yum install hg -y

编译到 go get gopkg.in/yaml.v1 的时候卡住不走了，说明是git比较低，版本需要大于1.7.9.5以上

fatal: Unable to find remote helper for 'https' 出现这个问题，可以重新安装 curl curl-devel 然后再重装git

安装git-core

1. wget https://www.kernel.org/pub/software/scm/git/git-core-0.99.6.tar.gz
2. tar zxvf git-core-0.99.6.tar.gz
3. cd git-core-0.99.6
4. make prefix=/usr/libexec/git-core install
5. export PATH=$PATH:/usr/libexec/git-core/

谢谢大家对本博客的支持，本站专注原创技术文章，请尊重原创，杜绝百度上面出现的各种一模一样的帖子，让我们一起努力做更优质的文章。且看且珍惜博主的心得。请转载带上本文链接注明出处。

如果大家有什么疑问可以加我QQ327388905进行解答，也可以加入交流群

群二维码

Sunny博客技术交流群：

![](http://www.sunnyos.com/public/home/images/SunnyBlog.png)

ThinkPHP交流群：

![](http://www.sunnyos.com/public/home/images/ThinkPHP.png)

Sunny博客技术交流群：57914191 [![Sunny博客技术交流群](http://pub.idqqimg.com/wpa/images/group.png)](http://shang.qq.com/wpa/qunwpa?idkey=0fb7a9bf017e8b2c44d0898f99b9b8eb00a03b1af94ffb4bd800495bd3ca40ee)

ThinkPHP交流群：57914282 [![ThinkPHP技术交流](http://pub.idqqimg.com/wpa/images/group.png)](http://shang.qq.com/wpa/qunwpa?idkey=abec7b437ed32fc847b71a4490259e3ac8e92cd8484929191d115bb9ec1e12d4)