title: 快速重置MariaDB或是MySQL的root密码
date: '2019-08-04 16:05:34'
updated: '2019-08-04 16:05:34'
tags: [待分类]
permalink: /articles/2019/08/04/1564905934651.html
---
转自[geekpi稿源:linux中国站](https://ywnz.com/linuxysjk/2971.html)

如果你在 Linux 下安装了 LAMP 服务器，然后用 root 用户进行登录数据库，但是忘记密码，你可以采用本文介绍的方法对 root 密码进行重置。

 

**关于搭建LAMP服务器的参考**

1.[在Ubuntu 18.04系统中安装LAMP服务器全过程](https://ywnz.com/linuxyffq/2833.html)

2.[Linux云服务器CentOS 7.4 64位PHP环境配置[LAMP]](https://ywnz.com/linuxyffq/2522.html)

3.[Debian搭建LAMP环境（Apache MariaDB PHP7）](https://ywnz.com/linuxyffq/511.html)

4.[Ubuntu 16.04 LTS搭建Apache,MariaDB PHP7(LAMP)](https://ywnz.com/linuxyffq/497.html)

 

**快速重置MariaDB或是MySQL的root密码详细方法如下**

1.首先，停止数据库。

如果你使用 MySQL，请输入以下命令并下按回车键。

$ sudo systemctl stop mysql

对于 MariaDB：

$ sudo systemctl stop mariadb

2.接下来，使用以下命令在没有权限检查的情况下重新启动数据库：

$ sudo mysqld_safe --skip-grant-tables &

这里， --skip-grant-tables 选项让你在没有密码和所有权限的情况下进行连接。如果使用此选项启动服务器，它还会启用 --skip-networking 选项，这用于防止其他客户端连接到数据库服务器。并且，& 符号用于在后台运行命令，因此你可以在以下步骤中输入其他命令。请注意，上述命令很危险，并且你的数据库会变得不安全。你应该只在短时间内运行此命令以重置密码。

3.然后以 root 用户身份登录 MariaDB/MySQL 服务器：

$ mysql

4.在 mysql > 或 MariaDB [(none)] > 提示符下，运行以下命令重置 root 用户密码：

UPDATE mysql.user SET Password=PASSWORD('NEW-PASSWORD') WHERE User='root';

使用你自己的密码替换上述命令中的 NEW-PASSWORD。

5.然后再输入以下命令退出 mysql 控制台。

FLUSH PRIVILEGES;

exit

6.最后，关闭之前使用 --skip-grant-tables 选项运行的数据库。为此，运行：

$ sudo mysqladmin -u root -p shutdown

系统将要求你输入在上一步中设置的 MariaDB/MySQL 用户密码。

7.现在，使用以下命令正常启动 MariaDB/MySQL 服务：

$ sudo systemctl start mysql

对于 MariaDB：

$ sudo systemctl start mariadb

8.使用以下命令验证密码是否确实已更改：

$ mysql -u root -p

至此，重置MariaDB或是MySQL的root密码就完成了。

 

**相关主题**

[如何在Ubuntu上安装MySQL/MariaDB](https://ywnz.com/linuxysjk/1245.html)
