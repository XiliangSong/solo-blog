title: CloudFlare免费CDN加速使用方法 【转自知乎】
date: '2019-08-04 16:26:01'
updated: '2019-08-04 16:26:01'
tags: [CloudFlare, CDN]
permalink: /articles/2019/08/04/1564907160971.html
---
转自[公众号JustThink](https://zhuanlan.zhihu.com/p/29891330)
# CloudFlare免费CDN加速使用方法

[![crystal](https://pic2.zhimg.com/v2-ddf3c47644330f3a1f84c2481a056c38_xs.jpg)](https://www.zhihu.com/people/crystal-33-50)

[crystal](https://www.zhihu.com/people/crystal-33-50)

公众号JustThink | 分享高效、实用、有趣的工具教程

​关注他

8 人赞同了该文章

## 前言

cloudflare 是一家国外的 CDN 加速服务商，还是很有名气的。提供免费和付费的加速和网站保护服务。百度云加速的国外节点就是和 cloudflare 合作使用的 cloudflare 的节点。

  

cloudflare 提供了不同类型的套餐，即使是免费用户，cloudflare 提供的功能也是很全面的。

  

对于访客来自于国外的网站很不错；对于访客来自于国内的网站加速效果有限，有些甚至会变慢，不过其安全防护功能也很不错。

  

## 添加网站

官网： [www.cloudflare.com](https://link.zhihu.com/?target=https%3A//www.cloudflare.com/)

使用邮箱注册，注册完后自动进入添加网站界面。添加网站分为四步：添加网站域名、添加DNS记录、选择方案、更新域名服务器。

  

![null](https://pic1.zhimg.com/80/v2-ebeaa66f209db0afa00a8546cb98de80_hd.jpg)

  

## 1.添加网站

填入自己的主域名（不带 www 的），“Scan DNS Records”。

  

## 2.添加DNS记录

添加完成后会自动扫描 DNS 记录，等待完成，“Continue”。

  

下面会列出所有扫描到的 DNS 记录。黄色云朵表示该解析通过 CDN 访问，灰色云朵表示不通过 CDN 访问，点击云朵可以切换状态。**这里如果选择不走 CDN 的话，相当于只使用 cloudflare 的 DNS 功能。**

  

这里建议全部调为黄色云朵走 CDN 访问，隐藏网站真实 IP 地址。全站通过 CDN 访问可以有效防止网站真实IP泄漏，保护原站安全。

  

记录简单的话可以直接按默认条目；如果没有扫描出来原记录或要手动添加，建议至少添加 @ 和 www 两条指向原网站 IP 的 A 记录，TTL 默认。

  

![null](https://pic1.zhimg.com/80/v2-f8804ee5469503437d739446995805ec_hd.jpg)

  

## 3.选择方案

选择适合自己的方案，一般小站博客免费方案就够了。当然，有更高需求的可按需选择付费方案。

  

![null](https://pic1.zhimg.com/80/v2-05b79fdeaf3bbfaaf1eca5dcfc650f50_hd.jpg)

  

## 4.更新域名服务器

右侧是新的域名服务器。进入域名管理面板，更改域名服务器为新的。

  

![null](https://pic2.zhimg.com/80/v2-9c2f5f20803243e9ca7ce5211971563d_hd.jpg)

  

域名服务器更改成功后会收到邮件提示。“Continue”，完成。

  

![null](https://pic2.zhimg.com/80/v2-948ac1bd2f9a812ce7f559a1c2262c01_hd.jpg)

  

## Tips

DNS 刷新生效需要时间，可耐心等待。

* 刷新本地 DNS

* cmd 运行 ipconfig /flushdns

* 查看域名服务器

* cmd 运行 nslookup —> 回车 —> set type=ns —> 回车 —> 域名

* 等生效后，再 ping 自己的域名，显示出来的就应该是 cloudflare 节点的 IP 地址了。

![null](https://pic4.zhimg.com/80/v2-ef9b6e80bcef18efd83efa6605fe60ff_hd.jpg)

  

## 效果

我的博客用的 Godaddy 的虚拟主机，国内访问速度比较慢 ╮（╯＿╰）╭，延迟 480ms。可以看到，使用 cloudflare 后本地测试延迟 251ms。还是可以的，比起我原来的速度好多了 o(￣▽￣)ｄ。

  

![null](https://pic4.zhimg.com/80/v2-bedd9dcbfbab65c4b3a2adbc76d6ec8b_hd.jpg)

  

![null](https://pic1.zhimg.com/80/v2-2183dda69ef4a6222422d5f79247c2e8_hd.jpg)

  

国内部分，Ping 结果比原来好多了。*（额，没用 CDN 时更惨）*

  

![null](https://pic1.zhimg.com/80/v2-29f7cab1c599155cfaecc7b5ae185258_hd.jpg)

  

国外部分，可以看到 cloudflare 在国外还是很厉害的。

  

![null](https://pic1.zhimg.com/80/v2-08ee33a2c9f791b2d43a5d093074b440_hd.jpg)

  

## 总结

* 网站对国外访客的效果很好，推荐使用；
* 对国内访客的效果说不上优秀，但也中规中矩吧，毕竟国外节点，个别时间、地区连接超时也是有的。

## 结语

本篇只介绍如何添加网站使用 cloudflare 的 CDN 加速和网站防护服务。至于其他深入配置下一篇再单独讲。不想配置的按默认选项也可以。

  

cloudflare 对于主机在国外、访客在国内的网站加速效果有限，安全防护还不错。不过对于没有备案的朋友来说国内的 CDN 服务是用不了了，相对而言使用 cloudflare 还是一个可选的途径。

  

当然，如果原站本身访问速度不错，使用了 cloudflare 可能变慢了；如果网站经常遭受恶意攻击什么的话，倒是可以用 cloudflare 来加强防护保护原站。