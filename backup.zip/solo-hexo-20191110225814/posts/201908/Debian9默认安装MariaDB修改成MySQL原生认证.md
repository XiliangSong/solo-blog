title: Debian 9 默认安装MariaDB  修改成 MySQL原生认证
date: '2019-08-04 16:13:12'
updated: '2019-08-04 20:20:03'
tags: [数据库, MySQL]
permalink: /articles/2019/08/04/1564906392799.html
---
Debian 9 使用 MariaDB 彻底代替了 MySQL。因此在配置方面，相比之前版本有很多的不同。

## 安装MariaDB

安装 MariaDB 仍旧可以使用下面的命令，相比使用 mariadb-server，使用 mysql-server 能够保证对 MySQL 的兼容性。

## 使用原生 MySQL 认证
使用原生 MySQL 认证因为默认使用了 UNIX SOCKET 认证，有些 phpMyAdmin 在登入时会发生 “Access Denied” 错误。我们可以更改 UNIX SOCKET 认证为原生 MySQL 认证.

```
1 update mysql.user set plugin = 'mysql_native_password' where User='root';   
2 flush privileges;  
3 quit;
```

最后，重启一下数据库即可
```
systemctl restart mariadb.service

```

如果重启失败，可以直接在控制面板里面重启服务器，终极武器.
--------------------- ---------------------
作者：Machanical-Thinking 
来源：CSDN 
原文：https://blog.csdn.net/qq_34302921/article/details/87111574 
版权声明：本文为博主原创文章，转载请附上博文链接！
