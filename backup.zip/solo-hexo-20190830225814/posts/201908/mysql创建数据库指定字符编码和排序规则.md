title: mysql创建数据库指定字符编码和排序规则
date: '2019-08-04 16:23:34'
updated: '2019-08-04 20:19:35'
tags: [MySQL]
permalink: /articles/2019/08/04/1564907014451.html
---
字符编码: utf8mb4   
排序规则: utf8mb4_general_ci   
```
**create database b3log_symphony default character set utf8mb4 collate utf8mb4_general_ci;**
```
